#!/bin/bash
set -u
cd /tmp/tms-pr124-dc1b676/cuda
unset TMS_PLATFORM
export CUDA_VISIBLE_DEVICES=0
export TMS_CUDA_MAJOR=13
export PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
run_step() {
  local label=$1
  shift
  printf '%q ' "$@" > "logs/$label.command"
  printf '\n' >> "logs/$label.command"
  "$@" > "logs/$label.log" 2>&1
  local result=$?
  echo "$result" > "logs/$label.exit"
  return "$result"
}
run_step tooling_dependencies python -m pip install typer==0.27.2 click==8.4.2
run_step hardware nvidia-smi
run_step toolkit nvcc --version
run_step environment python -c 'import sys,torch,importlib.metadata as m; print(sys.version); print(sys.executable); print("torch",torch.__version__,"cuda",torch.version.cuda); print("devices",torch.cuda.device_count()); print({k:m.version(k) for k in ["pytest","setuptools","packaging","typer"]})'
run_step build python setup.py build_ext --inplace || exit $?
run_step regression timeout 3600 python -m pytest test -vv -ra --junitxml=logs/regression.xml
run_step tooling python -m pytest test/test_merge_cuda_wheels.py test/test_setup_rpath.py .claude/skills/tms-publish-release/scripts/test_*.py -vv -ra --junitxml=logs/tooling.xml
run_step wheel python -m pip wheel --no-build-isolation --no-deps . -w dist
printf 'finished\n' > logs/done
