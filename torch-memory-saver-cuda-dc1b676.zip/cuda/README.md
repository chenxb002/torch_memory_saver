CUDA validation of dc1b67683d3eed5edbd4b39c3dc81b8530377ef1 (2026-11-20)

- One NVIDIA A100-SXM4-80GB in a newly created CAIP container; Python 3.12.3, NVIDIA PyTorch 2.11.0a0+eb65b36914.nv26.02, CUDA toolkit/runtime 13.1, driver 575.57.08.
- Full unmodified regression suite: 64 passed, 41 skipped in 89.04s, exit 0.
- Skips: 24 MLU-specific, 6 XPU-specific, 1 ROCm-specific, 7 multi-device, and 3 loader cases where ldconfig already resolves libcudart.so.13.
- Packaging/setup/release tooling: 84 passed in 0.58s, exit 0. Tooling overlaps with tests in the full suite.
- Native build, wheel build/install, and installed-wheel data/backup/pause/resume/address checks with explicit in-region MemPool destruction passed.

All attempts are retained. Initial tooling used image-provided Typer 0.24.0 and failed two CLI exception-shape checks; rerun with Typer 0.27.2 and Click 8.4.2 passed. The runtime regression ran before this CLI dependency adjustment. Initial installed-wheel smoke without explicit MemPool destruction passed its data assertions but exited with the free-region assertion previously documented in PR #121; the explicit-cleanup variant exited successfully. Both smoke scripts and logs are included.

The source snapshot is the exact PR tree. run-validation.sh reproduces the build/regression/tooling/wheel commands, with final CLI dependency versions. Per-step .command and .exit files record commands and exit codes; the final tooling rerun also included test/test_setup_rpath.py (see its log and run-validation.sh). wheel-smoke.py runs outside the source checkout with PYTHONPATH pointing to the installed wheel directory.

This validates one CUDA 13 A100 environment, not the CUDA 12/13 x86_64/ARM64 release matrix or multi-device CUDA.
