PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 python -m pytest test/test_merge_cuda_wheels.py test/test_setup_rpath.py .claude/skills/tms-publish-release/scripts/test_*.py -vv -ra --junitxml=logs/tooling.xml
