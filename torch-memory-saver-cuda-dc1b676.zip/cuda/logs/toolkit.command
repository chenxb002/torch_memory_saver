nvcc --version 
