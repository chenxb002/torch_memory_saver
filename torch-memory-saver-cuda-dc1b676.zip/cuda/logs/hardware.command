nvidia-smi 
