#!/bin/bash
set -u
cd /tmp/tms-pr124-dc1b676/mlu
unset TMS_PLATFORM TMS_CUDA_MAJOR
export MLU_VISIBLE_DEVICES=0,1
export PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
export NEUWARE_HOME=${NEUWARE_HOME:-/usr/local/neuware}
export LD_LIBRARY_PATH="$NEUWARE_HOME/lib64${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
run_step() {
  local label=$1
  shift
  printf '%q ' "$@" > "logs/$label.command"
  printf '\n' >> "logs/$label.command"
  "$@" > "logs/$label.log" 2>&1
  local result=$?
  echo "$result" > "logs/$label.exit"
  return "$result"
}
run_step environment python -c 'import sys,torch,torch_mlu,importlib.metadata as m; print(sys.version); print(sys.executable); print("torch",torch.__version__,"torch_mlu",torch_mlu.__version__); print("devices",torch.mlu.device_count()); print({k:m.version(k) for k in ["pytest","setuptools","packaging","typer"]})'
run_step build python setup.py build_ext --inplace || exit $?
if [ "${TMS_RUN_REGRESSION:-0}" = "1" ]; then
run_step regression timeout 3600 /tmp/tms-pr124-dc1b676/mlu-venv/bin/python -m pytest test -vv -ra --junitxml=logs/regression.xml
fi
run_step tooling /tmp/tms-pr124-dc1b676/mlu-venv/bin/python -m pytest test/test_merge_cuda_wheels.py test/test_setup_rpath.py .claude/skills/tms-publish-release/scripts/test_*.py -vv -ra --junitxml=logs/tooling.xml
run_step wheel python -m pip wheel --no-build-isolation --no-deps . -w dist
printf 'finished\n' > logs/done
