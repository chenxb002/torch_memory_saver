# Parent source tree with HEAD's regression test copied into test/test_setup_rpath.py.
python -m pytest test/test_setup_rpath.py::test_setup_detects_neuware_automatically -vv
