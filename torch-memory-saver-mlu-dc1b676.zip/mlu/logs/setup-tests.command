python -m pytest test/test_setup_rpath.py -vv -ra
