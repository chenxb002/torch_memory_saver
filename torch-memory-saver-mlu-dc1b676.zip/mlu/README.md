MLU validation of dc1b67683d3eed5edbd4b39c3dc81b8530377ef1 (2026-11-20)

- Two visible MLU devices on the existing shared host; Python 3.10.8, PyTorch 2.13.0+cpu, torch_mlu 1.34.1+torch2.13.0, installed Neuware SDK 4.7.6, driver 6.5.53. wheel-smoke.log includes actual runtime library versions.
- Full unmodified regression suite: 90 passed, 11 skipped, 3 failed in 741.82s, exit 1. This is NOT a full passing run.
- All 24 MLU-specific tests passed. Multi-device shared tests passed.
- Expected skips: 6 XPU-only, 1 ROCm-only, and 4 CUDA-only loader tests.
- Failures: test_cuda_graph[preload], test_cuda_graph[torch], test_training_engine. Both graph tests exhausted available device memory when requesting 3.73 GiB with only 2.43 GiB free. Training-engine allocation requested 4 GiB with only 3.33 GiB free. Existing workloads remained running throughout; tests were not reduced, excluded, or changed.
- Packaging/setup/release tooling: 84 passed in 0.98s, exit 0 (overlaps with tests in the full suite).
- TMS_PLATFORM was unset for native and wheel builds; both automatically selected MLU. Installed-wheel data/backup/pause/resume/address checks with explicit MemPool cleanup passed.
- The new detection regression fails on the parent source tree (selects CUDA), and passes on the PR tree. before-fix.log and setup-tests.log retain this evidence.

Initial test collection in the existing Python environments encountered an unrelated Megatron examples-package collision. Those attempts are retained. prepare-env.py created a separate venv using symlinks to the existing installed dependencies, excluding .pth hooks and unrelated editable installations; dependencies were reused, not freshly installed. The final runtime suite and final 84 tooling tests used this isolated import environment with pytest plugin autoload disabled. The original environment was used for native/wheel builds.

Reproduction: extract source.tar into the working directory; run prepare-env.py; run TMS_RUN_REGRESSION=1 bash run-validation.sh. Paths in the scripts describe this validation host. The source snapshot is the exact PR tree; test files were unmodified. See .command/.exit files and XML for precise evidence. The hardware log retains device memory usage but omits the process table for other workloads.

A fully passing MLU regression report requires rerunning the three failing tests with sufficient free memory; this run does not claim that result.
