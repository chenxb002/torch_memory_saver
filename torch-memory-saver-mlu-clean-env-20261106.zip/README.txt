MLU clean-environment validation (2026-11-06)

Hardware: two MLU590-M9DK devices (CN_VISIBLE_DEVICES=0,1), driver 6.5.53.
Python 3.10.8, torch 2.14.0+cpu, torch_mlu 1.35.0+torch2.14.0,
CNToolkit 4.7.5, CNRT 7.8.0; pytest 8.4.2, Typer 0.27.2, Click 8.4.2.
Fresh venv without system-site packages; freshly downloaded vendor torch_mlu wheel
was SHA256-verified. Native Neuware runtime is provided by the host.

FINAL RESULTS
- Full regression: 82 passed, 10 skipped in 710.45s; exit 0.
- Tooling: 82 passed in 0.80s; exit 0. Counts overlap with full regression.
- All 23 test/test_mlu.py cases passed, including both hook modes where supported.
- Shared multi-device, training engine, CPU/disk backup, graph and region cases passed.
- Skips: 6 XPU-specific cases and 4 CUDA-only loader cases.
- Wheel build/install and installed-wheel pause/CPU-backup/resume smoke passed.
- pip check: No broken requirements found.

COMMANDS (from the isolated source checkout, using the new venv)
TMS_PLATFORM=mlu python -m pip wheel . --no-deps --no-build-isolation -v -w ../wheels
TMS_PLATFORM=mlu python setup.py build_ext --inplace
CN_VISIBLE_DEVICES=0,1 python -m pytest test -vv -ra --tb=short --junitxml=../logs/regression.xml
CN_VISIBLE_DEVICES=0,1 python -m pytest test/test_merge_cuda_wheels.py test/test_setup_rpath.py .claude/skills/tms-publish-release/scripts/test_*.py -vv -ra --junitxml=../logs/tooling.xml
See run-validation.sh and continue-validation.sh for exact commands/environment.

SETUP DIAGNOSTIC
The initial backend import stopped before build/tests because torch_mlu's profiler
imports pandas without declaring it in wheel metadata. pandas 2.2.3 was installed,
then isolation/backend checks, build and all tests succeeded. Initial diagnostic
logs and driver.exitcode=1 are retained; continuation.exitcode=0 is the completed
validation result. No repository tests or production code were changed.
The vendor download-source metadata is intentionally not included; use the matching
vendor wheel recorded in download-torch-mlu.log when reproducing the bootstrap.

CONTENTS
Complete installation/build/test output, JUnit XML, environment and device details,
dependency lock files/reports, native library resolution, wheel/source hashes,
and execution scripts. ZIP does not contain the venv, wheels, or source tree.
Coverage is the current two-device MLU host; CUDA release matrices are separate.
