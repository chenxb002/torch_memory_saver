#!/usr/bin/env bash
set -euo pipefail
TASK_ROOT=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
mkdir -p "$TASK_ROOT/logs" "$TASK_ROOT/source" "$TASK_ROOT/wheels" "$TASK_ROOT/downloads"
exec > >(tee "$TASK_ROOT/logs/continuation.log") 2>&1
trap 'TASK_EXIT=$?; echo "$TASK_EXIT" > "$TASK_ROOT/logs/continuation.exitcode"' EXIT
date -u --iso-8601=seconds
unset PYTHONPATH PYTHONHOME PIP_EXTRA_INDEX_URL PIP_FIND_LINKS
unset PYTORCH_MLU_ALLOC_CONF PYTORCH_CUDA_ALLOC_CONF PYTORCH_HIP_ALLOC_CONF PYTORCH_ALLOC_CONF
unset TMS_INIT_ENABLE TMS_INIT_ENABLE_CPU_BACKUP TMS_INIT_CPU_BACKUP_BACKEND TMS_RETAIN_CPU_BACKUP
export PYTHONNOUSERSITE=1 PIP_CONFIG_FILE=/dev/null PIP_INDEX_URL=https://pypi.org/simple
export CN_VISIBLE_DEVICES=0,1 TMS_PLATFORM=mlu NEUWARE_HOME=/usr/local/neuware
export TORCH_DEVICE_BACKEND_AUTOLOAD=1
TASK_PYTHON="$TASK_ROOT/venv/bin/python"
export VIRTUAL_ENV="$TASK_ROOT/venv"
export PATH="$VIRTUAL_ENV/bin:$PATH"
"$TASK_PYTHON" -m pip install pandas==2.2.3 --report "$TASK_ROOT/logs/install-backend-dependencies-report.json" > "$TASK_ROOT/logs/install-backend-dependencies.log" 2>&1
"$TASK_PYTHON" - <<'PY' > "$TASK_ROOT/logs/environment.json" 2> "$TASK_ROOT/logs/backend-runtime.log"
import importlib.metadata,json,os,platform,site,sys
from pathlib import Path
import torch,torch_mlu,typer,click,pytest,numpy
assert not site.ENABLE_USER_SITE
assert torch.mlu.is_available() and torch.mlu.device_count()==2
assert torch.get_device_module() is torch.mlu
modules=dict(torch=torch,torch_mlu=torch_mlu,typer=typer,click=click,pytest=pytest,numpy=numpy)
for module in modules.values():
    assert Path(module.__file__).is_relative_to(sys.prefix),module.__file__
print(json.dumps(dict(python=platform.python_version(),cn_visible_devices=os.environ['CN_VISIBLE_DEVICES'],
    devices=[torch.mlu.get_device_name(i) for i in range(2)],
    versions={k:importlib.metadata.version(k) for k in modules},
    modules={k:v.__file__ for k,v in modules.items()}),indent=2))
PY
cat "$TASK_ROOT/logs/environment.json"
tar -xzf "$TASK_ROOT/source.tar.gz" -C "$TASK_ROOT/source"
cd "$TASK_ROOT/source"
"$TASK_PYTHON" -m pip wheel . --no-deps --no-build-isolation -v -w "$TASK_ROOT/wheels" > "$TASK_ROOT/logs/build-wheel.log" 2>&1
"$TASK_PYTHON" -m pip install --no-deps "$TASK_ROOT"/wheels/*.whl > "$TASK_ROOT/logs/install-wheel.log" 2>&1
cd "$TASK_ROOT"
"$TASK_PYTHON" - <<'PY' > "$TASK_ROOT/logs/installed-wheel-smoke.log" 2>&1
import sys,torch,torch_memory_saver
from pathlib import Path
assert Path(torch_memory_saver.__file__).is_relative_to(sys.prefix)
saver=torch_memory_saver.torch_memory_saver
saver.hook_mode='torch'
with saver.region('wheel',enable_cpu_backup=True):
    x=torch.full((1024,),7,device='mlu')
ptr=x.data_ptr()
saver.pause('wheel')
assert torch.all(saver.get_cpu_backup(x)==7).item()
saver.resume('wheel')
assert x.data_ptr()==ptr and torch.all(x==7).item()
print('Installed MLU wheel pause/backup/resume passed:',torch_memory_saver.__file__,flush=True)
PY
echo 0 > "$TASK_ROOT/logs/installed-wheel-smoke.exitcode"
cd "$TASK_ROOT/source"
"$TASK_PYTHON" setup.py build_ext --inplace > "$TASK_ROOT/logs/build-inplace.log" 2>&1
set +e
timeout 2400 "$TASK_PYTHON" -m pytest test -vv -ra --tb=short --junitxml="$TASK_ROOT/logs/regression.xml" > "$TASK_ROOT/logs/regression.log" 2>&1
TASK_REGRESSION_EXIT=$?
echo "$TASK_REGRESSION_EXIT" > "$TASK_ROOT/logs/regression.exitcode"
timeout 600 "$TASK_PYTHON" -m pytest test/test_merge_cuda_wheels.py test/test_setup_rpath.py .claude/skills/tms-publish-release/scripts/test_*.py -vv -ra --junitxml="$TASK_ROOT/logs/tooling.xml" > "$TASK_ROOT/logs/tooling.log" 2>&1
TASK_TOOLING_EXIT=$?
echo "$TASK_TOOLING_EXIT" > "$TASK_ROOT/logs/tooling.exitcode"
set -e
"$TASK_PYTHON" -m pip check > "$TASK_ROOT/logs/pip-check-after.log" 2>&1
"$TASK_PYTHON" -m pip freeze --all > "$TASK_ROOT/logs/requirements-final.txt"
cnmon > "$TASK_ROOT/logs/cnmon-after.log"
tail -40 "$TASK_ROOT/logs/regression.log"
tail -8 "$TASK_ROOT/logs/tooling.log"
date -u --iso-8601=seconds
test "$TASK_REGRESSION_EXIT" -eq 0 && test "$TASK_TOOLING_EXIT" -eq 0
