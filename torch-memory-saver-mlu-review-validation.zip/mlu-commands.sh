#!/bin/bash
set -eu
cd /workspace/verl_work/torch-memory-saver-pr121-refresh
export CN_VISIBLE_DEVICES=0,1 TMS_PLATFORM=mlu PYTHONPATH=.
TASK_PYTHON=/workspace/verl_work/tms-validation/mlu-clean-20261106/venv/bin/python
"$TASK_PYTHON" setup.py build_ext --inplace
"$TASK_PYTHON" -m pytest test -q -ra --tb=short
"$TASK_PYTHON" -m pytest test/test_utils.py test/test_setup_rpath.py test/test_merge_cuda_wheels.py .claude/skills/tms-publish-release/scripts/test_*.py -q --tb=short
