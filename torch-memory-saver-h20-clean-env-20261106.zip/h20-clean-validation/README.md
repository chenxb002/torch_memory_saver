# Clean-environment H20 validation: PR #1

Tested commit: 5ebc29987873f07e62adb44765e6385bd0fe4065
Date: 2026-11-06 (UTC)
Hardware: one NVIDIA H20-3e, driver 610.43.02, x86_64.
Python: 3.12.3; PyTorch: 2.14.1+cu130; PyTorch CUDA: 13.0.
Native build toolkit: CUDA 13.1 (see nvcc.txt).

## Results

- Initial empty-venv isolation assertions: passed.
- Fresh dependency installation and pip check: passed.
- Wheel build and installation: passed.
- Installed-wheel pause/backup/resume with explicit in-region pool cleanup, outside the source directory: passed (exit 0).
- Supplemental implicit-interpreter-exit smoke: lifecycle assertions passed, but shutdown failed with the existing CUDA free-region assertion (exit 1); reproduced on the baseline. See details below.
- Full regression: 54 passed, 39 skipped in 87.14s (0:01:27); exit 0.
- Tooling: 82 passed in 0.60s; exit 0.
- Final pip check: passed.
- No tests were deleted, deselected or weakened. No repository source changes.

## Environment isolation

Created with `python -m venv` WITHOUT `--system-site-packages`.
`PYTHONPATH` and `PYTHONHOME` were unset; `PYTHONNOUSERSITE=1` was set.
`isolation-before.json` records that Torch, Typer and Click were absent before installation.
`environment.json` records module locations inside the new venv.
PyTorch 2.14.1+cu130 was freshly installed from the official CUDA 13.0 wheel index.
Test dependencies were set before testing, including pytest 8.4.2, Typer 0.27.2,
Click 8.4.2, setuptools 80.9.0, wheel 0.45.1, packaging 25.0 and NumPy 2.2.6.
The CUDA driver/toolkit come from the H20 host/container; Python packages do not.
No dependency versions were adjusted after observing test results.

## Supplemental shutdown finding (not hidden)

The first extra installed-wheel smoke passed its pause/backup/resume assertions,
but interpreter shutdown invoked `tms_torch_free` outside an interesting region:
`only support interesting region`, exit 1. The unchanged PR baseline reproduced
exactly the same failure after passing lifecycle assertions. This is not a new
MLU PR regression. Production code and repository tests were not changed.
The initial driver consequently returned 1; `continue-validation.sh` then ran
all repository regression/tooling tests in the SAME environment, without changing
any dependency versions. It also verified explicit in-region pool cleanup, exit 0.

- `installed-wheel-smoke.log` / `driver.exitcode`: original supplemental failure.
- `baseline-exit-smoke.log` / `.exitcode`: baseline reproduction.
- `installed-wheel-explicit-cleanup.log` / `.exitcode`: controlled cleanup success.
- `continuation.log` / `.exitcode`: complete regression/tooling execution, exit 0.

To reproduce the full sequence, run `run-clean-validation.sh`, then
`continue-validation.sh` after inspecting the known supplemental shutdown failure.
`check-baseline-exit.sh` uses a separately extracted/built baseline tree.

## Included evidence

Full install logs and pip installation reports (URLs and package hashes),
complete dependency version lists, environment-isolation evidence,
wheel/in-place build logs, installed-wheel smoke log, complete pytest logs,
JUnit XML, exit codes, GPU usage snapshots, reproduction script and SHA256SUMS.
The optional PyTorch prefetch downloaded the same official wheel into pip's cache;
it did not install packages or change the selected versions.

## Coverage limits

This is single-GPU CUDA source/wheel validation, not the CUDA 12/13 x86_64/ARM64
release matrix. Multi-GPU, MLU and XPU runtime scenarios remain skipped as recorded
in regression.log. Three preload-loader scenarios may skip when ldconfig already
resolves libcudart.so.13; see the exact skip summary in regression.log.
