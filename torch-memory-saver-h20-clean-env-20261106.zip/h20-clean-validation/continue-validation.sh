#!/usr/bin/env bash
set -euo pipefail
TASK_ROOT=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
exec > >(tee "$TASK_ROOT/logs/continuation.log") 2>&1
trap 'TASK_EXIT=$?; echo "$TASK_EXIT" > "$TASK_ROOT/logs/continuation.exitcode"' EXIT
unset PYTHONPATH PYTHONHOME PIP_EXTRA_INDEX_URL PIP_FIND_LINKS
export PYTHONNOUSERSITE=1 PIP_CONFIG_FILE=/dev/null
export CUDA_VISIBLE_DEVICES=0 TMS_PLATFORM=cuda TMS_CUDA_MAJOR=13
export LD_LIBRARY_PATH=/usr/local/cuda/lib64
TASK_PYTHON="$TASK_ROOT/venv/bin/python"
cd "$TASK_ROOT/source"
"$TASK_PYTHON" setup.py build_ext --inplace > "$TASK_ROOT/logs/build-inplace.log" 2>&1
set +e
timeout 3600 "$TASK_PYTHON" -m pytest test -vv -ra --tb=short --junitxml="$TASK_ROOT/logs/regression.xml" > "$TASK_ROOT/logs/regression.log" 2>&1
TASK_REGRESSION_EXIT=$?
echo "$TASK_REGRESSION_EXIT" > "$TASK_ROOT/logs/regression.exitcode"
timeout 600 "$TASK_PYTHON" -m pytest test/test_merge_cuda_wheels.py test/test_setup_rpath.py .claude/skills/tms-publish-release/scripts/test_*.py -vv -ra --junitxml="$TASK_ROOT/logs/tooling.xml" > "$TASK_ROOT/logs/tooling.log" 2>&1
TASK_TOOLING_EXIT=$?
echo "$TASK_TOOLING_EXIT" > "$TASK_ROOT/logs/tooling.exitcode"
set -e
cd "$TASK_ROOT"
"$TASK_PYTHON" - <<'PY' > "$TASK_ROOT/logs/installed-wheel-explicit-cleanup.log" 2>&1
import gc, sys, torch, torch_memory_saver
from pathlib import Path
assert Path(torch_memory_saver.__file__).is_relative_to(sys.prefix)
saver = torch_memory_saver.torch_memory_saver
saver.hook_mode = 'torch'
with saver.region('wheel', enable_cpu_backup=True):
    x = torch.full((1024,), 7, device='cuda')
ptr = x.data_ptr()
saver.pause('wheel')
assert torch.all(saver.get_cpu_backup(x) == 7).item()
saver.resume('wheel')
assert x.data_ptr() == ptr and torch.all(x == 7).item()
with saver._impl._with_region_config(tag='wheel', enable_cpu_backup=True, cpu_backup_backend='pinned'):
    del x
    saver._impl._mem_pools.clear()
    gc.collect()
    torch.cuda.empty_cache()
assert saver._impl._affected_devices('wheel') == []
print('Installed wheel lifecycle with explicit in-region pool cleanup passed:', torch_memory_saver.__file__)
PY
echo 0 > "$TASK_ROOT/logs/installed-wheel-explicit-cleanup.exitcode"
"$TASK_PYTHON" -m pip check > "$TASK_ROOT/logs/pip-check-after.log" 2>&1
"$TASK_PYTHON" -m pip freeze --all > "$TASK_ROOT/logs/requirements-final.txt"
nvidia-smi --query-gpu=index,name,driver_version,memory.total,memory.used,utilization.gpu --format=csv > "$TASK_ROOT/logs/gpu-after.csv"
tail -35 "$TASK_ROOT/logs/regression.log"
tail -8 "$TASK_ROOT/logs/tooling.log"
date -u --iso-8601=seconds
test "$TASK_REGRESSION_EXIT" -eq 0 && test "$TASK_TOOLING_EXIT" -eq 0
