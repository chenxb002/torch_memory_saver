#!/usr/bin/env bash
set -euo pipefail
TASK_ROOT=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
unset PYTHONPATH PYTHONHOME
export PYTHONNOUSERSITE=1 CUDA_VISIBLE_DEVICES=0 LD_LIBRARY_PATH=/usr/local/cuda/lib64
cd "$TASK_ROOT/baseline"
set +e
"$TASK_ROOT/venv/bin/python" - <<'PY' > "$TASK_ROOT/logs/baseline-exit-smoke.log" 2>&1
import torch, torch_memory_saver
print('Baseline package:', torch_memory_saver.__file__, flush=True)
saver = torch_memory_saver.torch_memory_saver
saver.hook_mode = 'torch'
with saver.region('wheel', enable_cpu_backup=True):
    x = torch.full((1024,), 7, device='cuda')
ptr = x.data_ptr()
saver.pause('wheel')
assert torch.all(saver.get_cpu_backup(x) == 7).item()
saver.resume('wheel')
assert x.data_ptr() == ptr and torch.all(x == 7).item()
print('Baseline lifecycle passed before interpreter shutdown', flush=True)
PY
TASK_EXIT=$?
echo "$TASK_EXIT" > "$TASK_ROOT/logs/baseline-exit-smoke.exitcode"
exit "$TASK_EXIT"
