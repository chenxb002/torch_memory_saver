#!/usr/bin/env bash
set -euo pipefail
TASK_ROOT=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
mkdir -p "$TASK_ROOT/logs" "$TASK_ROOT/source" "$TASK_ROOT/wheels"
exec > >(tee "$TASK_ROOT/logs/driver.log") 2>&1
trap 'TASK_EXIT=$?; echo "$TASK_EXIT" > "$TASK_ROOT/logs/driver.exitcode"' EXIT
date -u --iso-8601=seconds
unset PYTHONPATH PYTHONHOME PIP_EXTRA_INDEX_URL PIP_FIND_LINKS
export PYTHONNOUSERSITE=1 PIP_CONFIG_FILE=/dev/null
export PIP_INDEX_URL=https://pypi.org/simple
export CUDA_VISIBLE_DEVICES=0 TMS_PLATFORM=cuda TMS_CUDA_MAJOR=13
export LD_LIBRARY_PATH=/usr/local/cuda/lib64
python -m venv "$TASK_ROOT/venv"
TASK_PYTHON="$TASK_ROOT/venv/bin/python"
cat "$TASK_ROOT/venv/pyvenv.cfg" > "$TASK_ROOT/logs/pyvenv.cfg"
"$TASK_PYTHON" - <<'PY' > "$TASK_ROOT/logs/isolation-before.json"
import importlib.util, json, site, sys
assert sys.prefix != sys.base_prefix
assert not site.ENABLE_USER_SITE
assert importlib.util.find_spec('torch') is None
assert importlib.util.find_spec('typer') is None
assert importlib.util.find_spec('click') is None
assert not any('/usr/local/lib/python' in p and ('site-packages' in p or 'dist-packages' in p) for p in sys.path)
print(json.dumps(dict(prefix=sys.prefix, base_prefix=sys.base_prefix, user_site=site.ENABLE_USER_SITE, sys_path=sys.path), indent=2))
PY
"$TASK_PYTHON" -m pip install --upgrade pip > "$TASK_ROOT/logs/install-pip.log" 2>&1
uv pip install --python "$TASK_PYTHON" --index-url https://download.pytorch.org/whl/cu130 torch==2.14.1+cu130 > "$TASK_ROOT/logs/install-torch.log" 2>&1
"$TASK_PYTHON" -m pip install pytest==8.4.2 typer==0.27.2 click==8.4.2 setuptools==80.9.0 wheel==0.45.1 packaging==25.0 numpy==2.2.6 nvidia-ml-py --report "$TASK_ROOT/logs/install-tools-report.json" > "$TASK_ROOT/logs/install-tools.log" 2>&1
"$TASK_PYTHON" -m pip freeze --all > "$TASK_ROOT/logs/requirements-lock.txt"
"$TASK_PYTHON" -m pip check > "$TASK_ROOT/logs/pip-check.log" 2>&1
"$TASK_PYTHON" - <<'PY' > "$TASK_ROOT/logs/environment.json"
import importlib.metadata, json, platform, site, sys, torch, typer, click, pytest
from pathlib import Path
assert torch.cuda.is_available()
assert torch.__version__ == '2.14.1+cu130'
assert not site.ENABLE_USER_SITE
modules = dict(torch=torch, typer=typer, click=click, pytest=pytest)
for module in modules.values():
    assert Path(module.__file__).is_relative_to(sys.prefix), module.__file__
print(json.dumps(dict(python=platform.python_version(), torch=torch.__version__, cuda=torch.version.cuda,
    devices=[torch.cuda.get_device_name(i) for i in range(torch.cuda.device_count())],
    modules={k:v.__file__ for k,v in modules.items()},
    versions={k:importlib.metadata.version(k) for k in modules}), indent=2))
PY
cat "$TASK_ROOT/logs/environment.json"
nvidia-smi --query-gpu=index,name,driver_version,memory.total,memory.used,utilization.gpu --format=csv > "$TASK_ROOT/logs/gpu-before.csv"
nvcc --version > "$TASK_ROOT/logs/nvcc.txt"
tar -xzf "$TASK_ROOT/source.tar.gz" -C "$TASK_ROOT/source"
cd "$TASK_ROOT/source"
"$TASK_PYTHON" -m pip wheel . --no-deps --no-build-isolation -v -w "$TASK_ROOT/wheels" > "$TASK_ROOT/logs/build-wheel.log" 2>&1
"$TASK_PYTHON" -m pip install --no-deps "$TASK_ROOT"/wheels/*.whl > "$TASK_ROOT/logs/install-wheel.log" 2>&1
cd "$TASK_ROOT"
"$TASK_PYTHON" - <<'PY' > "$TASK_ROOT/logs/installed-wheel-smoke.log" 2>&1
import sys, torch, torch_memory_saver
from pathlib import Path
assert Path(torch_memory_saver.__file__).is_relative_to(sys.prefix)
saver = torch_memory_saver.torch_memory_saver
saver.hook_mode = 'torch'
with saver.region('wheel', enable_cpu_backup=True):
    x = torch.full((1024,), 7, device='cuda')
ptr = x.data_ptr()
saver.pause('wheel')
assert torch.all(saver.get_cpu_backup(x) == 7).item()
saver.resume('wheel')
assert x.data_ptr() == ptr and torch.all(x == 7).item()
with saver.region('cleanup'):
    del x
    torch.cuda.empty_cache()
print('Installed wheel pause/backup/resume and explicit cleanup passed:', torch_memory_saver.__file__)
PY
cd "$TASK_ROOT/source"
"$TASK_PYTHON" setup.py build_ext --inplace > "$TASK_ROOT/logs/build-inplace.log" 2>&1
set +e
timeout 3600 "$TASK_PYTHON" -m pytest test -vv -ra --tb=short --junitxml="$TASK_ROOT/logs/regression.xml" > "$TASK_ROOT/logs/regression.log" 2>&1
TASK_REGRESSION_EXIT=$?
echo "$TASK_REGRESSION_EXIT" > "$TASK_ROOT/logs/regression.exitcode"
timeout 600 "$TASK_PYTHON" -m pytest test/test_utils.py test/test_merge_cuda_wheels.py test/test_setup_rpath.py .claude/skills/tms-publish-release/scripts/test_*.py -vv -ra --junitxml="$TASK_ROOT/logs/tooling.xml" > "$TASK_ROOT/logs/tooling.log" 2>&1
TASK_TOOLING_EXIT=$?
echo "$TASK_TOOLING_EXIT" > "$TASK_ROOT/logs/tooling.exitcode"
set -e
"$TASK_PYTHON" -m pip check > "$TASK_ROOT/logs/pip-check-after.log" 2>&1
"$TASK_PYTHON" -m pip freeze --all > "$TASK_ROOT/logs/requirements-final.txt"
nvidia-smi --query-gpu=index,name,driver_version,memory.total,memory.used,utilization.gpu --format=csv > "$TASK_ROOT/logs/gpu-after.csv"
tail -35 "$TASK_ROOT/logs/regression.log"
tail -8 "$TASK_ROOT/logs/tooling.log"
date -u --iso-8601=seconds
test "$TASK_REGRESSION_EXIT" -eq 0 && test "$TASK_TOOLING_EXIT" -eq 0
