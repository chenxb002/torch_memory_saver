import concurrent.futures, hashlib, os
from pathlib import Path
import requests
from packaging.tags import sys_tags
from packaging.utils import parse_wheel_filename
root=Path('/workspace/tms-pr121-review/downloads');root.mkdir(exist_ok=True)
tags=set(sys_tags())
versions={'nvidia-cudnn-cu13':'9.24.0.43','nvidia-cublas':'13.1.1.3','nvidia-cusparselt-cu13':'0.8.1','nvidia-nccl-cu13':'2.30.7','nvidia-nvjitlink':'13.5.37','triton':'3.8.0'}
assets=[]
for name,version in versions.items():
 r=requests.get(f'https://pypi.org/pypi/{name}/{version}/json',timeout=30);r.raise_for_status()
 a=next(x for x in r.json()['urls'] if x['filename'].endswith('.whl') and parse_wheel_filename(x['filename'])[3]&tags)
 p=root/a['filename'];fd=os.open(str(p)+'.part',os.O_CREAT|os.O_RDWR,0o600);os.ftruncate(fd,a['size']);assets.append((a,p,fd))
def fetch(a,fd,start,end):
 for attempt in range(4):
  try:
   r=requests.get(a['url'].replace('https://files.pythonhosted.org', 'https://mirrors.aliyun.com/pypi'),headers={'Range':f'bytes={start}-{end}'},timeout=120);r.raise_for_status()
   assert r.status_code==206 and len(r.content)==end-start+1
   os.pwrite(fd,r.content,start);return
  except Exception:
   if attempt==3:raise
def missing(fd,start,end):
 try:
  return os.lseek(fd,start,os.SEEK_HOLE) < end+1
 except OSError:
  return True
with concurrent.futures.ThreadPoolExecutor(max_workers=32) as pool:
 jobs=[pool.submit(fetch,a,fd,start,min(start+4*1024*1024,a['size'])-1) for a,p,fd in assets for start in range(0,a['size'],4*1024*1024) if missing(fd,start,min(start+4*1024*1024,a['size'])-1)]
 for f in concurrent.futures.as_completed(jobs):f.result()
for a,p,fd in assets:
 os.close(fd);part=Path(str(p)+'.part');h=hashlib.sha256()
 with part.open('rb') as f:
  for block in iter(lambda:f.read(8*1024*1024),b''):h.update(block)
 assert h.hexdigest()==a['digests']['sha256']
 part.rename(p);print('SHA256 verified',p.name,flush=True)
print('DONE',flush=True)
