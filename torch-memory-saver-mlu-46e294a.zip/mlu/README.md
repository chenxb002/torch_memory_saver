MLU validation of 46e294a2dd1fc1fed92481e0c2a709be6326a96e on 2026-11-20

Full unmodified regression: 93 passed, 11 skipped, 14 warnings in 739.78s, exit 0.
All 24 MLU-specific tests passed. Both graph tests and training_engine that previously exhausted available device memory passed in this full rerun. Two idle MLU devices (0,1) were exposed; no tests or allocation sizes were changed or excluded.

Packaging/setup/release tooling: 84 passed in 1.08s, exit 0. These cases overlap with the full regression suite.
Expected skips: six XPU-only, one ROCm-only, four CUDA-only loader tests.

Automatic MLU native and wheel builds with TMS_PLATFORM unset passed. Wheel installation and installed-wheel pause/CPU-backup/resume/data/address checks with explicit MemPool cleanup passed.

Python 3.10.8, PyTorch 2.13.0+cpu, torch_mlu 1.34.1+torch2.13.0, Neuware SDK 4.7.6, driver 6.5.53. The previously prepared isolated import environment reused existing dependencies; prepare-env.py records its preparation. This is not a fresh dependency installation. Build and test commands and exit statuses are in logs/; JUnit XML and exact source snapshot are included. run-validation.sh records the final workflow.

Initial wheel packaging in the isolated import environment failed because its setuptools command module did not match the installed metadata. The original build environment was then used for wheel packaging and installation; both passed, followed by the successful smoke check in the isolated import environment. All initial attempts are retained in *-initial-environment logs. No repository source change was needed.

The source tree is identical to dc1b676; the intervening commit amend only corrected author/committer metadata. The earlier CUDA validation therefore covers the same source. The old MLU OOM run remains available in the separate dc1b676 archive as history, superseded by this complete passing rerun.
