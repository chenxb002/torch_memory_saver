"""Reuse installed MLU dependencies without unrelated editable installs or .pth hooks."""
from pathlib import Path
import venv
venv.create('/tmp/tms-pr124-dc1b676/mlu-venv', with_pip=True)
src=Path('/torch/venv3/pytorch_infer/lib/python3.10/site-packages')
dst=Path('/tmp/tms-pr124-dc1b676/mlu-venv/lib/python3.10/site-packages')
for p in src.iterdir():
    if p.suffix in ('.pth','.egg-link') or p.name.startswith('__editable__') or p.name.startswith('torch_memory_saver') or (dst/p.name).exists():
        continue
    (dst/p.name).symlink_to(p, target_is_directory=p.is_dir())
