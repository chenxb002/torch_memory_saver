import gc
import torch
import torch_memory_saver as package
from torch_memory_saver import torch_memory_saver as saver
from torch_memory_saver.testing_utils import get_device, get_device_module
print('package:', package.__file__, flush=True)
assert '/installed/' in package.__file__
saver.hook_mode = 'torch'
mod = get_device_module()
with saver.region(enable_cpu_backup=True, cpu_backup_backend='mmap'):
    expected = torch.arange(4096, dtype=torch.int64)
    tensor = expected.to(get_device())
    address = tensor.data_ptr()
    assert torch.equal(tensor.cpu(), expected)
    saver.pause()
    backup = saver.get_cpu_backup(tensor)
    assert backup is not None and torch.equal(backup, expected)
    del backup
    saver.resume()
    assert tensor.data_ptr() == address
    assert torch.equal(tensor.cpu(), expected)
    assert saver.get_cpu_backup(tensor) is None
    del tensor
    gc.collect()
    mod.empty_cache()
with saver._impl._with_region_config(tag='default', enable_cpu_backup=True, cpu_backup_backend='mmap'):
    saver._impl._mem_pools.clear()
    gc.collect()
print('Installed-wheel pause/CPU-backup/resume and explicit in-region cleanup passed', flush=True)
