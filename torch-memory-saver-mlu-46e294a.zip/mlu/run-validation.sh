#!/bin/bash
set -u
cd /tmp/tms-pr124-46e294a-rerun/mlu
unset TMS_PLATFORM TMS_CUDA_MAJOR
export MLU_VISIBLE_DEVICES=0,1
export CN_VISIBLE_DEVICES=0,1
export NEUWARE_HOME=/usr/local/neuware
export LD_LIBRARY_PATH="$NEUWARE_HOME/lib64${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
export PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
export PATH="/tmp/tms-pr124-dc1b676/mlu-venv/bin:$PATH"
run_step() {
  local label=$1
  shift
  printf '%q ' "$@" > "logs/$label.command"
  printf '\n' >> "logs/$label.command"
  "$@" > "logs/$label.log" 2>&1
  local result=$?
  echo "$result" > "logs/$label.exit"
  return "$result"
}
run_step hardware cnmon
run_step environment python -c 'import sys,torch,torch_mlu,importlib.metadata as m; print(sys.version); print(sys.executable); print("torch",torch.__version__,"torch_mlu",torch_mlu.__version__); print("devices",torch.mlu.device_count()); print({k:m.version(k) for k in ["pytest","setuptools","packaging","typer","click"]}); print("sys.path",sys.path)'
run_step toolkit cat /usr/local/neuware/version.txt
run_step build python setup.py build_ext --inplace || exit $?
run_step regression timeout 3600 python -m pytest test -vv -ra --junitxml=logs/regression.xml
run_step tooling python -m pytest test/test_merge_cuda_wheels.py test/test_setup_rpath.py .claude/skills/tms-publish-release/scripts/test_*.py -vv -ra --junitxml=logs/tooling.xml
run_step wheel /torch/venv3/pytorch_infer/bin/python -m pip wheel --no-build-isolation --no-deps . -w dist
run_step wheel-install /torch/venv3/pytorch_infer/bin/python -m pip install --no-deps --target installed dist/*.whl
(cd /tmp && PYTHONPATH=/tmp/tms-pr124-46e294a-rerun/mlu/installed python /tmp/tms-pr124-46e294a-rerun/wheel-smoke.py) > logs/wheel-smoke.log 2>&1
echo "$?" > logs/wheel-smoke.exit
printf 'finished\n' > logs/done
