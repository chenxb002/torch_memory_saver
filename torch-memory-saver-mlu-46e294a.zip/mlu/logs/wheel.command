env -u TMS_PLATFORM -u TMS_CUDA_MAJOR NEUWARE_HOME=/usr/local/neuware /torch/venv3/pytorch_infer/bin/python -m pip wheel --no-build-isolation --no-deps . -w dist
