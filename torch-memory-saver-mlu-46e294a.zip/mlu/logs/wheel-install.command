/torch/venv3/pytorch_infer/bin/python -m pip install --no-deps --target installed dist/*.whl
