cat /usr/local/neuware/version.txt 
