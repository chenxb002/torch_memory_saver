#!/usr/bin/env bash
set -euo pipefail
TASK_ROOT=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
mkdir -p "$TASK_ROOT/logs" "$TASK_ROOT/source" "$TASK_ROOT/wheels" "$TASK_ROOT/downloads"
exec > >(tee "$TASK_ROOT/logs/driver.log") 2>&1
trap 'TASK_EXIT=$?; echo "$TASK_EXIT" > "$TASK_ROOT/logs/driver.exitcode"' EXIT
date -u --iso-8601=seconds
unset PYTHONPATH PYTHONHOME PIP_EXTRA_INDEX_URL PIP_FIND_LINKS
unset PYTORCH_MLU_ALLOC_CONF PYTORCH_CUDA_ALLOC_CONF PYTORCH_HIP_ALLOC_CONF PYTORCH_ALLOC_CONF
unset TMS_INIT_ENABLE TMS_INIT_ENABLE_CPU_BACKUP TMS_INIT_CPU_BACKUP_BACKEND TMS_RETAIN_CPU_BACKUP
export PYTHONNOUSERSITE=1 PIP_CONFIG_FILE=/dev/null PIP_INDEX_URL=https://pypi.org/simple
export CN_VISIBLE_DEVICES=0,1 TMS_PLATFORM=mlu NEUWARE_HOME=/usr/local/neuware
export TORCH_DEVICE_BACKEND_AUTOLOAD=1
TASK_PYTHON="$TASK_ROOT/venv/bin/python"
export VIRTUAL_ENV="$TASK_ROOT/venv"
export PATH="$VIRTUAL_ENV/bin:$PATH"
cp "$TASK_ROOT/venv/pyvenv.cfg" "$TASK_ROOT/logs/pyvenv.cfg"
cp "$TASK_ROOT/provenance.json" "$TASK_ROOT/logs/provenance.json"
cnmon > "$TASK_ROOT/logs/cnmon-before.log"
"$TASK_PYTHON" - <<'PY' > "$TASK_ROOT/logs/isolation-before.json"
import importlib.util,json,site,sys
assert sys.prefix != sys.base_prefix
assert not site.ENABLE_USER_SITE
for name in ('torch','torch_mlu','typer','click','pytest'):
    assert importlib.util.find_spec(name) is None, name
print(json.dumps(dict(prefix=sys.prefix,base_prefix=sys.base_prefix,sys_path=sys.path,user_site=site.ENABLE_USER_SITE),indent=2))
PY
"$TASK_PYTHON" -m pip install --upgrade pip > "$TASK_ROOT/logs/install-pip.log" 2>&1
"$TASK_PYTHON" -m pip install --index-url https://download.pytorch.org/whl/cpu torch==2.14.0+cpu --report "$TASK_ROOT/logs/install-torch-report.json" > "$TASK_ROOT/logs/install-torch.log" 2>&1
"$TASK_PYTHON" - "$TASK_ROOT" <<'PY' > "$TASK_ROOT/logs/download-torch-mlu.log" 2>&1
import hashlib,json,sys,urllib.request,urllib.parse
from pathlib import Path
root=Path(sys.argv[1]);info=json.loads((root/'torch-mlu-wheel-source.json').read_text())
name=Path(urllib.parse.unquote(urllib.parse.urlparse(info['url']).path)).name
target=root/'downloads'/name
urllib.request.urlretrieve(info['url'],target)
digest=hashlib.sha256(target.read_bytes()).hexdigest()
assert digest==info['archive_info']['hashes']['sha256']
print(json.dumps(dict(filename=name,sha256=digest,source='Original vendor wheel matching the existing torch_mlu installation'),indent=2))
PY
"$TASK_PYTHON" -m pip install "$TASK_ROOT"/downloads/torch_mlu-*.whl black==23.12.1 pandas==2.2.3 numpy==1.26.4 pytest==8.4.2 typer==0.27.2 click==8.4.2 setuptools==80.9.0 wheel==0.45.1 packaging==25.0 nvidia-ml-py --report "$TASK_ROOT/logs/install-tools-report.json" > "$TASK_ROOT/logs/install-tools.log" 2>&1
"$TASK_PYTHON" -m pip freeze --all > "$TASK_ROOT/logs/requirements-lock.txt"
"$TASK_PYTHON" -m pip check > "$TASK_ROOT/logs/pip-check.log" 2>&1
"$TASK_PYTHON" - <<'PY' > "$TASK_ROOT/logs/environment.json" 2> "$TASK_ROOT/logs/backend-runtime.log"
import importlib.metadata,json,os,platform,site,sys
from pathlib import Path
import torch,torch_mlu,typer,click,pytest,numpy
assert not site.ENABLE_USER_SITE
assert torch.mlu.is_available() and torch.mlu.device_count()==2
assert torch.get_device_module() is torch.mlu
modules=dict(torch=torch,torch_mlu=torch_mlu,typer=typer,click=click,pytest=pytest,numpy=numpy)
for module in modules.values():
    assert Path(module.__file__).is_relative_to(sys.prefix),module.__file__
print(json.dumps(dict(python=platform.python_version(),cn_visible_devices=os.environ['CN_VISIBLE_DEVICES'],
    devices=[torch.mlu.get_device_name(i) for i in range(2)],
    versions={k:importlib.metadata.version(k) for k in modules},
    modules={k:v.__file__ for k,v in modules.items()}),indent=2))
PY
cat "$TASK_ROOT/logs/environment.json"
tar -xzf "$TASK_ROOT/source.tar.gz" -C "$TASK_ROOT/source"
cd "$TASK_ROOT/source"
"$TASK_PYTHON" -m pip wheel . --no-deps --no-build-isolation -v -w "$TASK_ROOT/wheels" > "$TASK_ROOT/logs/build-wheel.log" 2>&1
"$TASK_PYTHON" -m pip install --no-deps "$TASK_ROOT"/wheels/*.whl > "$TASK_ROOT/logs/install-wheel.log" 2>&1
cd "$TASK_ROOT"
"$TASK_PYTHON" - <<'PY' > "$TASK_ROOT/logs/installed-wheel-smoke.log" 2>&1
import sys,torch,torch_memory_saver
from pathlib import Path
assert Path(torch_memory_saver.__file__).is_relative_to(sys.prefix)
saver=torch_memory_saver.torch_memory_saver
saver.hook_mode='torch'
with saver.region('wheel',enable_cpu_backup=True):
    x=torch.full((1024,),7,device='mlu')
ptr=x.data_ptr()
saver.pause('wheel')
assert torch.all(saver.get_cpu_backup(x)==7).item()
saver.resume('wheel')
assert x.data_ptr()==ptr and torch.all(x==7).item()
print('Installed MLU wheel pause/backup/resume passed:',torch_memory_saver.__file__,flush=True)
PY
echo 0 > "$TASK_ROOT/logs/installed-wheel-smoke.exitcode"
cd "$TASK_ROOT/source"
"$TASK_PYTHON" setup.py build_ext --inplace > "$TASK_ROOT/logs/build-inplace.log" 2>&1
set +e
timeout 2400 "$TASK_PYTHON" -m pytest test -vv -ra --tb=short --junitxml="$TASK_ROOT/logs/regression.xml" > "$TASK_ROOT/logs/regression.log" 2>&1
TASK_REGRESSION_EXIT=$?
echo "$TASK_REGRESSION_EXIT" > "$TASK_ROOT/logs/regression.exitcode"
timeout 600 "$TASK_PYTHON" -m pytest test/test_utils.py test/test_merge_cuda_wheels.py test/test_setup_rpath.py .claude/skills/tms-publish-release/scripts/test_*.py -vv -ra --junitxml="$TASK_ROOT/logs/tooling.xml" > "$TASK_ROOT/logs/tooling.log" 2>&1
TASK_TOOLING_EXIT=$?
echo "$TASK_TOOLING_EXIT" > "$TASK_ROOT/logs/tooling.exitcode"
set -e
"$TASK_PYTHON" -m pip check > "$TASK_ROOT/logs/pip-check-after.log" 2>&1
"$TASK_PYTHON" -m pip freeze --all > "$TASK_ROOT/logs/requirements-final.txt"
cnmon > "$TASK_ROOT/logs/cnmon-after.log"
tail -40 "$TASK_ROOT/logs/regression.log"
tail -8 "$TASK_ROOT/logs/tooling.log"
date -u --iso-8601=seconds
test "$TASK_REGRESSION_EXIT" -eq 0 && test "$TASK_TOOLING_EXIT" -eq 0
